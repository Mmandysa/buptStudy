
class Human {
    private String name;
    private int age;
    private int id;

    // 构造器
    Human() {
        this.name = "";
        this.age = 0;
        this.id = 0;
    }

    Human(String name, int age, int id) {
        this.age = age;
        this.name = name;
        this.id = id;
    }

    @Override
    public String toString() {
        return "id: " + this.id + "\nname: " + this.name + "\nage: " + this.age;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this)
            return true;
        if (obj == null)
            return false;
        if (this.getClass() != obj.getClass())
            return false;
        Human other = (Human) obj;
        return (this.name.equals(other.name) && this.id == other.id && this.age == other.age);
    }

    @Override
    public int hashCode() {
        return this.name.hashCode() * 7 + this.age * 31 + this.id * 29;
    }
}

class Student extends Human {
    private String school;

    Student() {
        school = "";
    }

    Student(String name, int age, int id, String school) {
        super(name, age, id);
        this.school = school;
    }

    @Override
    public String toString() {
        return super.toString() + "\nschool: " + this.school;
    }

    @Override

    public boolean equals(Object obj) {

        if (!(super.equals(obj)))
            return false;
        if (!(obj instanceof Student))
            return false;
        Student other = (Student) obj;
        return this.school.equals(other.school);
    }

    @Override
    public int hashCode() {
        return super.hashCode() + this.school.hashCode() * 19;
    }

}

public class Human_Student {

    public static void main(String[] args) {
        // 创建
        Human human1 = new Human("mandysa", 25, 1);
        Human human2 = new Human("mandysa", 25, 1);
        Human human3 = new Human("tys", 19, 6);
        Human temp_Human = null;

        Student stu1 = new Student("mandy", 18, 2, "icpc");
        Student stu2 = new Student("mandy", 18, 2, "icpc");
        Student stu3 = new Student("tys", 19, 6, "buppt");
        Student temp_Student;

        // 进行转换
        System.out.println("将stu1向上转型为temp_Human后输出temp_Human:");
        if (stu1 instanceof Human) {
            temp_Human = (Human) stu1;
            System.out.println(temp_Human.toString());
            // 此处会调用Student中的toString而不是Human中的
        }
        System.out.println("将temp_Human向下转型为temp_Student输出temp_Student:");
        if (temp_Human instanceof Student) {
            temp_Student = (Student) temp_Human;
            System.out.println(temp_Student.toString());
        }
        // equals测试
        System.out.println("Student-equals测试:");
        System.out.println("  stu1.equals(stu2):" + stu1.equals(stu2));
        System.out.println("  stu1.equals(stu3):" + stu1.equals(stu3));
        System.out.println("  stu1hash:" + stu1.hashCode());
        System.out.println("  stu2hash:" + stu2.hashCode());
        System.out.println("  stu3hash:" + stu3.hashCode());

        System.out.println("Human-equals测试:");
        System.out.println("  human1.equals(human2):" + human1.equals(human2));
        System.out.println("  human1.equals(human3):" + human1.equals(human3));
        System.out.println("  human1hash:" + human1.hashCode());
        System.out.println("  human2hash:" + human2.hashCode());
        System.out.println("  human3hash:" + human3.hashCode());

        System.out.println(human3.equals(stu3));
        System.out.println(stu3.equals(human3));

    }

}