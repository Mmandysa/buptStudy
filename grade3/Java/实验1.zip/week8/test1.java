package week8;

class Circle {
    private double radius;

    Circle(double r) {
        this.radius = r;
    }

    public double getR() {
        return this.radius;
    }

    public Circle setR(double r) {
        this.radius = r;
        return this;
    }

    double findArea() {
        return this.radius * this.radius * Math.PI;
    }

}

class PassObject {
    public void printAreas(Circle c, int times) {
        for (int i = 1; i <= times; i++) {
            System.out.printf("%.1f\t", c.setR(i).getR());
            System.out.println(c.setR(i).findArea());
        }
    }
}

public class test1 {
    public static void main(String[] args) {
        Circle cir = new Circle(0);
        PassObject pass = new PassObject();
        System.out.println("Radius\t Area");
        pass.printAreas(cir, 5);

    }
}