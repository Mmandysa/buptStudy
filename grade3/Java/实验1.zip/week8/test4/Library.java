package week8.test4;

import java.util.ArrayList;

public class Library {
    String location;
    ArrayList<Book> storeBooks = new ArrayList<Book>();

    // Add the missing implementation to this class
    Library(String location) {
        this.location = location;
    }

    // 打印时间
    public static void printOpeningHours() {
        System.out.println("Libraries are open daily from 9am to 5pm.");
    }

    // 打印地址
    public void printAddress() {
        System.out.println(this.location);
    }

    // 存书
    public void addBook(Book abook) {
        this.storeBooks.add(abook);
    }

    // 借书
    public void borrowBook(String bookname) {
        boolean have = false;
        for (int i = 0; i < storeBooks.size(); i++) {
            if (storeBooks.get(i).getTitle().equals(bookname)) {
                have = true;
                if (storeBooks.get(i).isBorrowed()) {
                    System.out.println("Sorry, this book is already borrowed.");
                } else {
                    storeBooks.get(i).rented();
                    System.out.println("You successfully borrowed " + bookname);
                }
            }
        }
        if (!have) {
            System.out.println("Sorry, this book is not in our catalog.");
        }

    }

    // 打印可借阅书籍
    public void printAvailableBooks() {
        if (storeBooks.size() == 0) {
            System.out.println("No book in catalog");
        }
        for (int i = 0; i < storeBooks.size(); i++) {
            if (!storeBooks.get(i).isBorrowed()) {
                System.out.println(storeBooks.get(i).getTitle());
            }
        }
    }

    // 还书
    public void returnBook(String bookname) {
        for (int i = 0; i < storeBooks.size(); i++) {
            if (storeBooks.get(i).getTitle().equals(bookname)) {
                storeBooks.get(i).returned();
                System.out.println("You successfully returned " + bookname);
            }
        }

    }

    public static void main(String[] args) {
        // Create two libraries
        Library firstLibrary = new Library("10 Main St.");
        Library secondLibrary = new Library("228 Liberty St.");

        // Add four books to the first library
        firstLibrary.addBook(new Book("The Da Vinci Code"));
        firstLibrary.addBook(new Book("Le Petit Prince"));
        firstLibrary.addBook(new Book("A Tale of Two Cities"));
        firstLibrary.addBook(new Book("The Lord of the Rings"));

        // Print opening hours and the addresses
        System.out.println("Library hours:");
        printOpeningHours();
        System.out.println();

        System.out.println("Library addresses:");
        firstLibrary.printAddress();
        secondLibrary.printAddress();
        System.out.println();

        // Try to borrow The Lords of the Rings from both libraries
        System.out.println("Borrowing The Lord of the Rings:");
        firstLibrary.borrowBook("The Lord of the Rings");
        firstLibrary.borrowBook("The Lord of the Rings");
        secondLibrary.borrowBook("The Lord of the Rings");
        System.out.println();

        // Print the titles of all available books from both libraries
        System.out.println("Books available in the first library:");
        firstLibrary.printAvailableBooks();
        System.out.println();
        System.out.println("Books available in the second library:");
        secondLibrary.printAvailableBooks();
        System.out.println();

        // Return The Lords of the Rings to the first library
        System.out.println("Returning The Lord of the Rings:");
        firstLibrary.returnBook("The Lord of the Rings");
        System.out.println();

        // Print the titles of available from the first library
        System.out.println("Books available in the first library:");
        firstLibrary.printAvailableBooks();
    }
}