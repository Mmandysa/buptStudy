package week8;

import java.time.*;
import java.util.*;

public class test3 {
    public static void main(String[] args) {
        System.out.println("请输入出生日期,格式'2007 12 3':");
        Scanner input = new Scanner(System.in);
        int birYear = input.nextInt();
        int birMonth = input.nextInt();
        int birDay = input.nextInt();
        input.close();
        int needLeap = 0;

        // 2.29需要判断闰年
        if (birMonth == 2 && birDay == 29) {
            needLeap = 1;
        }

        double[] sum = new double[8];
        int sumYear = 0;

        LocalDate today = LocalDate.now();
        LocalDate firstDay = LocalDate.of(birYear, birMonth, birDay).minusDays(birDay - 1);

        DayOfWeek firstWeekday;
        while (firstDay.getYear() < today.getYear()) {
            // 不需要判断闰年或者(需要判断闰年且这一年是闰年)则打印该月日历
            // 否则只让年份++

            if (needLeap == 0 || (needLeap == 1 && Year.isLeap(firstDay.getYear()))) {
                sumYear++;
                System.out.println(firstDay.getYear());
                System.out.println("Mon Tue Wed Thu Fri Sat Sun");
                firstWeekday = firstDay.getDayOfWeek();
                int value = firstWeekday.getValue();

                for (int i = 1; i < value; i++) {
                    System.out.print("    ");
                }

                while (firstDay.getMonthValue() == birMonth) {
                    System.out.printf("%3d", firstDay.getDayOfMonth());
                    if (firstDay.getDayOfMonth() == birDay) {
                        System.out.print("*");
                        sum[firstDay.getDayOfWeek().getValue()]++;

                    } else {
                        System.out.print(" ");
                    }
                    firstDay = firstDay.plusDays(1);
                    if (firstDay.getDayOfWeek().getValue() == 1) {
                        System.out.println();
                    }
                }
                firstDay = firstDay.minusMonths(1);
                // 恢复月份为本月
                System.out.println("\n");
            }

            firstDay = firstDay.plusYears(1);
        }
        System.out.printf("星期一:%.3f\n", sum[1] / sumYear);
        System.out.printf("星期二:%.3f\n", sum[2] / sumYear);
        System.out.printf("星期三:%.3f\n", sum[3] / sumYear);
        System.out.printf("星期四:%.3f\n", sum[4] / sumYear);
        System.out.printf("星期五:%.3f\n", sum[5] / sumYear);
        System.out.printf("星期六:%.3f\n", sum[6] / sumYear);
        System.out.printf("星期日:%.3f\n", sum[7] / sumYear);
    }

}
