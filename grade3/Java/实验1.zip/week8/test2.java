package week8;

import java.util.*;

public class test2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("input: ");
        String[] words = input.nextLine().split(" ");
        input.close();
        if (words.length > 2) {
            // 最后一个字符串的最后一个字符改为逗号
            String temp = words[words.length - 1];
            words[words.length - 1] = temp.substring(0, temp.length() - 1) + ",";

            // 将第三个单词首字母大写
            temp = words[2];
            words[2] = temp.toUpperCase().charAt(0) + temp.substring(1, temp.length());

            // 将第一个单词字母小写
            temp = words[0];
            words[0] = temp.toLowerCase().charAt(0) + temp.substring(1, temp.length());

            String word1 = words[0];
            String word2 = words[1];

            // 在第二个单词后加上问号
            word2 = word2 + "?";
            int i = 0;
            // 移动单词
            for (i = 0; i < words.length - 2; i++) {
                words[i] = words[i + 2];
            }
            words[i] = word1;
            words[++i] = word2;
            String str = String.join(" ", words);
            System.out.print("output: " + str);
        } else {
            System.out.println("输入的句子太短");
        }

    }
}
