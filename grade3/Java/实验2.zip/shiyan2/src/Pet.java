import java.text.DecimalFormat;


/** This is a class to define Pet objects. Pets should be compared 
according to their owner's names, ignoring capitalization. Ties
should be broken based on the pet's name, ignoring capitalization.

Your job is to add the necessary data and methods to support the
P3main program, as well as the related classes in this system. Some
required methods are noted below with comments, but these are not the
only things you will need.
*/
public class Pet implements Comparable<Pet> {

   /** Handy for formatting. */
   private static DecimalFormat money = new DecimalFormat("0.00");

   /* The access specifiers for these variables must not be changed!  private static DecimalFormat money = new DecimalFormat("0.00");*/

   private String name;
   private String owner;
   private double weight;
   private double sumCost;//花费的总金额
   private int visitTimes;//来医院的次数

   /** Create a Pet object, initializing data members.
    *  @param pname the Pet's name
    *  @param oname the owner's name
    *  @param wt the weight of the pet
    */
   //构造器
   public Pet(String pname, String oname, double wt) {
      this.name=pname;
      this.owner=oname;
      this.weight=wt;
      //初始化花费金额和来访次数为0
      this.sumCost=0;
      this.visitTimes=0;
   }

   public double getWeight() {
      return weight;
   }

   public String getName() {
      return name;
   }

   public String getOwner() {
      return owner;
   }

   @Override
   public String toString() {
      return this.name + " (owner " + this.owner + ") " + this.weight
          + " lbs, $" + money.format(this.avgCost()) + " avg cost/visit  ";
   }

   @Override
   public int compareTo(Pet otherPet){
      //忽略大小写比较
      if(this.owner.compareToIgnoreCase(otherPet.getOwner())==0){
         return this.name.compareToIgnoreCase(otherPet.getName());
      }
      else return this.owner.compareToIgnoreCase(otherPet.getOwner());
   }

   @Override
   public boolean equals(Object obj){
      if(obj==null) return false;
      if(this==obj) return true;
      if(this.getClass()!=obj.getClass())return false;
      Pet otherPet=(Pet)obj;
      //由于不能用Objects忽略大小写判断,直接用String类的equalsIgnoreCase判断需考虑是否为null
      return  (this.name == null ? otherPet.name == null :this.name.equalsIgnoreCase(otherPet.name))
              && (this.owner == null ? otherPet.owner == null :this.owner.equalsIgnoreCase(otherPet.owner));
   }

   /** The Pet is visiting the vet, and will be charged accordingly.
    *  The base cost for a visit is $85.00, and $30/shot is added.
    *  @param shots the number of shots the pet is getting
    *  @return the entire cost for this particular visit
    */
   public double visit(int shots) {
      this.visitTimes++;
      //固定费85,每多一次shot加30
      double thiscost=85.00+30*shots;
      //父类实现了对sumCost费用中基础费和基础shot费加和
      sumCost+=thiscost;
      //对于一般宠物,总金额只有每次来打针和固定费之和
      return thiscost;
   }

   /** Determine the average cost per visit for this pet.
    *  @return that cost, or 0 if no visits have occurred yet
    */
   public double avgCost() {
      //为零特殊处理
      if(visitTimes==0)return 0;
      return sumCost/visitTimes;
   }

   //提供addCost方法便于在子类中添加特殊的Cost
   public void addCost(double add){
      this.sumCost+=add;
   }
}
