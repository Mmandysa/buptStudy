import java.util.Arrays;

/** Class to keep track of client (Pet) information for a Veterinary
    practice. Some methods are sketched for you, but others will need
    to be added in order to implement the Database interface and
    support the P3main program and expected output. You'll also need
    to add the data members.
*/
public class Vet implements Database {

    private String who;
    private int size;//当前宠物数
    private int startsize;//最大容量
    Pet[] clients=new Pet[STARTSIZE];
    double sumWeight;
   /** Create a veterinary practice.
    * @param startSize the capacity for how
    * many clients they can handle
    * @param who the name of the vet practice
    */
   public Vet(int startSize, String who) {
        this.startsize=startSize;
        this.who=who;
        clients=new Pet[startsize];
        this.size=0;
        this.sumWeight=0;
   }

   public int size(){
       return this.size;
   }

   //查找
   public Object find(Object o){
       if(o==null) return null;
       if(!(o instanceof Pet)) return false;
       Pet findPet=(Pet)o;
       for(int i=0;i<size;i++){
           if(clients[i].equals(findPet))return clients[i];
       }
       return null;
   }

    /** Display the name of the Vet and all the clients, one per line,
     * on the screen. (See sample output for exact format.)
    */
   public void display() {
       System.out.println("Vet "+this.who+" client list: ");
        for(int i=0;i<this.size;i++){
            System.out.println(this.clients[i].toString());
        }
   }


    /** Add an item to the database, if there is room.
        You are limited by the initial capacity.
        @param o the object to add (must be a Pet)
        @return true if added, false otherwise
    */
   public boolean add(Object o) {
       if(o == null) return false;
       if(!(o instanceof  Pet))   return false;
       if(this.size==startsize){
            return false;
       }
       else{
           Pet newpet=(Pet) o;
           clients[size]=newpet;
           //修改现有数量和总重
           this.size++;
           this.sumWeight+= newpet.getWeight();
           return true;
       }
   }

    /** Delete an item from the database, if it is there,
        maintaining the current ordering of the list.
        @param o the object to delete
        @return the item if one is deleted, null otherwise
    */
   public Object delete(Object o) {
        if(o==null)return null;
        if(!(o instanceof Pet))return null;
        Pet delPet=(Pet)o;
        int i;
        for(i=0;i<size;i++){
            if(clients[i].equals(delPet)){
                for(;i<size-1;i++){
                    clients[i]=clients[i+1];
                }
                this.size--;
                //修改现有数量和总重
                this.sumWeight-= delPet.getWeight();
                return delPet;
            };
        }
        return null;

   }

    /** Compute the average weight over all clients.
        @return the average
    */
   public double averageWeight() {
       if(this.size!=0)return sumWeight/size;
       else return 0;
   }

    /** Sort the clients. (This is complete.)
     */
   public void sort() {
       Arrays.sort(this.clients, 0, this.size());
   }

}
