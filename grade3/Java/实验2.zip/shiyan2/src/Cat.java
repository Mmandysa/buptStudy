public class Cat extends Pet{
    //新增私有变量,是否是户外猫
    private String state;

    Cat(String pname,String owner,double weight){
        super(pname,owner,weight);
        this.state="inside";
    }

    public void goOutside(){
        this.state="outside";
    }

    @Override
    public double visit(int shots){
        //非户外猫
        if(state.equals("inside")) {
            super.addCost(20);
            //每次visit,室内猫的总花费加一次洗牙费20
            //对于固定费和shot费用通过调用super.visit(shots)来增加
            //super.visit(shots)中实现了对sumCost加上固定费和shots的修改
            return super.visit(shots)+20;
        }
        //户外猫
        else {
            //每次visit,室外猫的总花费加一次洗牙费:20和额外的一次shot:30
            //需手动调用addCost修改
            this.addCost(50);
            //对于固定费和shot费用通过调用super.visit(shots)来增加
            return super.visit(shots)+50;
        }
    }
    @Override
    public String toString(){
        return this.state+" cat "+super.toString();
    }
}
