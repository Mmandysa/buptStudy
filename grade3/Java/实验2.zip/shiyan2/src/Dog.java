public class Dog extends Pet{
    //新增私有变量,体型
    private String size;

    Dog(String pname,String owner,double wt,String size){
        super(pname,owner,wt);
        this.size=size;
    }

    @Override
    public double visit(int shots){
        //中型
        if (this.size.equals("medium")){
            //与Cat类似,额外费用手动添加
            //medium:15剪指甲+2.5每次shot额外费用
            super.addCost(15+2.5*shots);
            return super.visit(shots)+15+2.5*shots;
        }
        //大型
        else if (this.size.equals("large")) {
            //large:15剪指甲+5每次shot额外费用
            super.addCost(15+5*shots);
            return super.visit(shots)+15+5*shots;
        }
        //一般
        else{
            super.addCost(15);
            return super.visit(shots)+15;
        }
    }
    @Override
    public String toString(){
        return this.size+" dog "+super.toString();
    }
}
