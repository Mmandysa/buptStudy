import java.util.Scanner;

public class homework3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a Binary String:");
        String binary = input.nextLine();
        input.close();

        // 异常判断,非二进制字符串直接退出
        for (int i = 0; i < binary.length(); i++) {
            if (binary.charAt(i) != '0' && binary.charAt(i) != '1') {
                System.out.println("Error: Invalid Binary String \"" + binary + "\"");
                System.exit(0);
            }
        }

        // 转化
        int result = 0;
        for (int i = binary.length() - 1; i >= 0; i--) {
            result += (binary.charAt(i) - '0') * mypow(2, binary.length() - 1 - i);
        }
        System.out.println("The equalent decimal number is: " + result);
    }

    public static int mypow(int a, int b) {
        int pow = 1;
        // 当ab同时为0时,返回-1
        if (b == 0 && a == 0) {
            return -1;
        }
        for (int i = 0; i < b; i++) {
            pow *= a;
        }
        return pow;
    }
}
