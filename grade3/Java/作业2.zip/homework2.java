import java.util.Scanner;

public class homework2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int num1 = input.nextInt();
        input.nextLine(); // 防止换行符的干扰
        System.out.print("Enter a floating point number: ");
        double num2 = input.nextDouble();
        input.nextLine(); // 防止换行符的干扰,保证nextLine()读入的不是空
        System.out.print("Enter your name: ");
        String name = input.nextLine();
        System.out.println("Hi! " + name + ", the sum of " + num1 + " and " + num2 + " is " + (num1 + num2));
        input.close();
    }
}
