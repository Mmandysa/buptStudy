import java.util.Scanner;

public class homework4 {
    public static void main(String[] args) {
        String[] hexBits = { "0000", "0001", "0010", "0011",
                "0100", "0101", "0110", "0111",
                "1000", "1001", "1010", "1011",
                "1100", "1101", "1110", "1111" };
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a binary number: ");
        String hex = input.nextLine();
        System.out.print("The equivalent binary for hexadecimal " + "\"" + hex + "\" is:");
        for (int i = 0; i < hex.length(); i++) {
            System.out.print(" ");
            // 数字
            if (hex.charAt(i) >= '0' && hex.charAt(i) <= '9') {
                System.out.print(hexBits[hex.charAt(i) - '0']);
            }
            // 小写字母
            else if (hex.charAt(i) >= 'a' && hex.charAt(i) <= 'f') {
                System.out.print(hexBits[hex.charAt(i) - 'a' + 10]);
            }
            // 其他字符
            else {
                System.out.print("Invalid input!");
            }
        }
        System.out.println();
        input.close();
    }
}
