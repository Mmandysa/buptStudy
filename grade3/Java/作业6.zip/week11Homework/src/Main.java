import java.awt.*;
import java.awt.geom.Ellipse2D;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        EventQueue.invokeLater(()->{
            var frame=new SimpleFrame();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}
class SimpleFrame extends JFrame {
    //获取当前屏幕大小
    Toolkit kit=Toolkit.getDefaultToolkit();
    Dimension screen=kit.getScreenSize();
    private final int screenWidth=screen.width;
    private final int screenHeight=screen.height;
    public SimpleFrame(){
        //正方形窗口
        int width=screenHeight/2;
        int height=screenHeight/2;
        //设置icon
        Image image=kit.getImage("assets/bupt.png");
        setIconImage(image);
        //设置title
        setTitle("Smile");
        setSize(width,height);
        setLocation((screenWidth-width)/2,(screenHeight-height)/2);
        add(new SimpleCompoent());
    }
}
class SimpleCompoent extends JComponent{
    @Override
    public void paintComponent(Graphics g){
        Graphics2D g2=(Graphics2D) g;
        //获得正方形边长
        int a=getWidth();
        //外圆
        int centerY=a/20*9;
        int centerX=a/2;
        int R=a/5*2;
        Ellipse2D eps=new Ellipse2D.Double();
        eps.setFrameFromCenter(centerX,centerY,centerX+R,centerY+R);
        g2.setPaint(Color.YELLOW);
        g2.fill(eps);
        g2.draw(eps);

        //左眼
        centerX=a/10*3;
        centerY=a/4;
        R=a/20;
        eps.setFrameFromCenter(centerX,centerY,centerX+R,centerY+R);
        g2.setColor(Color.BLACK);
        g2.fill(eps);
        g2.draw(eps);

        //右眼,Y与左眼相同
        centerX=a/10*7;
        R=a/20;
        eps.setFrameFromCenter(centerX,centerY,centerX+R,centerY+R);
        g2.setColor(Color.BLACK);
        g2.fill(eps);
        g2.draw(eps);

        //嘴下半部分
        int leftX=a/20*3;
        int leftY=a/10;
        R=a/20*7;
        g2.setColor(Color.BLACK);
        g2.fillArc(leftX,leftY,R*2,R*2,180,180);

        //嘴上半部分
        leftY=a/5-1;
        g2.setColor(Color.YELLOW);
        g2.fillArc(leftX,leftY,R*2,(R-a/10)*2,180,180);

        //底部文字
        g2.setColor(Color.BLUE);
        g2.setFont(new Font("Serif", Font.BOLD, 20));
        String text="Smiling...";
        //设置居中
        FontMetrics fm=g2.getFontMetrics();
        int textWidth=fm.stringWidth(text);
        g2.drawString(text,(a-textWidth)/2,a/10*9);
    }

}