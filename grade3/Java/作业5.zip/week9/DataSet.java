package week9;

import week9.*;

public class DataSet {

   public DataSet() {
      sum = 0;
      count = 0;
      maximum = 0;
      obj = null;
   }

   /**
    * Adds a data value to the data set
    * 
    * @param x a data value
    */
   public void add(InterfaceToGetValue x) {
      sum = sum + x.getValue();
      if (count == 0 || maximum < x.getValue()) {
         maximum = x.getValue();
         obj = x;
      }
      count++;
   }

   /**
    * Gets the average of the added data.
    * 
    * @return the average or 0 if no data has been added
    */
   public double getAverage() {
      if (count == 0)
         return 0;
      else
         return sum / count;
   }

   /**
    * Gets the largest of the added data.
    * 
    * @return the maximum or 0 if no data has been added
    */
   public double getMaximum() {
      return maximum;
   }

   public InterfaceToGetValue getMaxobj() {
      return obj;
   }

   private double sum;
   private double maximum;
   private int count;
   private InterfaceToGetValue obj;

   public static void main(String[] args) {
      Student stu1 = new Student("mandy", 10, "bupt");
      Student stu2 = new Student("ti", 20, "iii");
      Student stu3 = new Student("tia", 24, "bupt");
      Human human1 = new Human("saa", 18);
      Human human2 = new Human("msa", 25);
      Human human3 = new Human("mssa", 19);

      DataSet dataset = new DataSet();
      dataset.add(stu1);
      dataset.add(stu2);
      dataset.add(stu3);
      dataset.add(human1);
      dataset.add(human2);
      dataset.add(human3);

      System.out.println("最大的对象:" + dataset.getMaxobj().toString() + " 对应的值:" + dataset.maximum);
      System.out.println("average:" + dataset.getAverage());
   }
}
