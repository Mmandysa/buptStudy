package week9;

public interface InterfaceToGetValue {
    double getValue();
}

class Human implements InterfaceToGetValue {
    private String name;
    private int age;

    public Human() {
        name = "";
        age = 0;
    }

    public Human(String name, int age) {
        this.age = age;
        this.name = name;
    }

    public double getValue() {
        return this.age;
    }

    public String toString() {
        return this.name;
    }
}

class Student extends Human {
    private String school;

    public Student() {
        super();
        this.school = "";
    }

    public Student(String name, int age, String school) {
        super(name, age);
        this.school = school;
    }

    public String getSchool() {
        return this.school;
    }

    public double getValue() {
        return super.getValue();
    }

}
