import java.time.LocalTime;

// Timer类中的时间是24制小时存储
// 根据is24Hour,返回两种计时模式的对应功能实现

class Timer {
    private int hour;
    private int minute;
    private boolean is24Hour;

    // 默认当前时间创建24小时制
    public Timer() {
        this.hour = LocalTime.now().getHour();
        this.minute = LocalTime.now().getMinute();
        this.is24Hour = true;
    }

    // 选择以12还是24小时制创建当前时间
    // 内部全部采用24小时制存储
    public Timer(boolean is) {
        this.hour = LocalTime.now().getHour();
        this.minute = LocalTime.now().getMinute();
        this.is24Hour = is;
    }

    // 自定义时间及模式创建
    // 类的内部采用24小时制存储
    // 如果要设置时间为12小时制的下午三点,应传入hour=15,minute=0,is24Hour=false
    public Timer(int hour, int minute, boolean is24Hour) {
        this.hour = hour;
        this.minute = minute;
        this.is24Hour = is24Hour;
    }

    // 根据不同时制返回转化后的小时数
    public int getHour() {
        if (!this.is24Hour) {
            if (this.hour <= 12) {
                return this.hour;
            } else {
                return this.hour - 12;
            }
        }
        return this.hour;
    }

    // 返回分钟数
    public int getMinute() {
        return this.minute;
    }

    // 小时数
    public void addHour() {
        this.hour = (this.hour + 1) % 24;
    }

    public void addHour(int add) {
        this.hour = (this.hour + add) % 24;
    }

    // 分钟数
    public void addMinute() {
        this.minute = (this.minute + 1) % 60;
    }

    public void addMinute(int add) {
        this.minute = (this.minute + add) % 60;
        // 超过60分钟换算成小时
        if (add >= 60) {
            this.addHour(add / 60);
        }
    }

    public String toString() {
        if (this.is24Hour) {
            return String.format("%02d:%02d", this.hour, this.minute);
        } else {
            if (this.hour <= 12) {
                return String.format("%d:%02d AM", this.hour, this.minute);
            } else {
                return String.format("%d:%02d PM", this.hour - 12, this.minute);
            }
        }

    }
}

public class homework {

    public static void main(String[] args) {
        System.out.println("24小时制测试:");
        System.out.println("1.设置时间");
        Timer time1 = new Timer();
        System.out.println("当前小时:" + time1.getHour() + " 分钟:" + time1.getMinute());
        System.out.println("当前时间:" + time1.toString());
        System.out.println("2.增加时间");
        time1.addHour();
        System.out.println("默认增加1小时:" + time1.toString());
        time1.addMinute(75);
        System.out.println("增加75分钟:" + time1.toString());
        System.out.println();

        System.out.println("12小时制测试:");
        System.out.println("1.设置时间");
        Timer time2 = new Timer(11, 50, false);
        System.out.println("当前小时:" + time2.getHour() + " 分钟:" + time2.getMinute());
        System.out.println("当前时间:" + time2.toString());
        System.out.println("2.增加时间");
        time2.addHour();
        System.out.println("默认增加1小时:" + time2.toString());
        time2.addMinute(75);
        System.out.println("增加75分钟:" + time2.toString());
    }

}
